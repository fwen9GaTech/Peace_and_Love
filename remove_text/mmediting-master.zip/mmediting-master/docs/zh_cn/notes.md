## 基准

详情请参阅 [model_zoo](https://mmediting.readthedocs.io/en/latest/modelzoo.html)。
