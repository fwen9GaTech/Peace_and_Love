# Copyright (c) OpenMMLab. All rights reserved.
from .lr_updater import LinearLrUpdaterHook

__all__ = ['LinearLrUpdaterHook']
