# Copyright (c) OpenMMLab. All rights reserved.
from .cain_net import CAINNet

__all__ = ['CAINNet']
